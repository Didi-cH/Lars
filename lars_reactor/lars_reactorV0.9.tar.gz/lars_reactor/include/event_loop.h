#pragma once

#include <sys/epoll.h>
#include <unordered_map>
#include <unordered_set>

#include "event_base.h"

// 一次性最大处理的事件
#define MAXEVENTS 10

class event_loop
{
public:
    //构造，初始化epoll堆
    event_loop();

    //阻塞循环监听并处理事件
    void event_process();

    //添加一个io事件到event_loop中
    void add_io_event(int fd, io_callback *proc, int mask, void *args=nullptr);

    //删除一个io事件从event_loop中
    void del_io_event(int fd);

    //删除一个io事件的触发条件(EPOLLIN/EPOLLOUT)
    void del_io_event(int fd, int mask);

private:
    int _epfd;  //通过epoll_create创建的根节点 epoll fd

    //当前event_loop 监控的fd和对应事件的关系
    // key:fd--> value:io_event
    std::unordered_map<int, io_event> _io_evs;

    //当前event_loop 都有哪些fd在监听
    //epoll_wait()正在等待哪些fd触发状态
    //作用是将当前的服务器可以主动发送消息给客户端
    //当前fd集合 表示在线的fd
    // value:fd 全部正在监听的fd集合
    std::unordered_set<int> listen_fds;

    //每次epoll_wait()返回触发，所返回的被激活的事件集合
    struct epoll_event _fired_evs[MAXEVENTS];
};