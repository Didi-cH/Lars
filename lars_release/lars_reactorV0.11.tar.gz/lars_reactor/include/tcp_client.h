#pragma once
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "net_connection.h"
#include "reactor_buf.h"
#include "event_loop.h"
#include "message.h"

class tcp_client: public net_connection
{
public:
    //初始化客户端套接字
    tcp_client(event_loop *loop, const char *ip, uint16_t port);

    //发送方法
    int send_message(const char *data, int msglen, int msgid);

    //处理读业务
    void do_read();

    //处理写业务
    void do_write();

    //链接服务器
    void do_connect();

    //释放连接
    void clean_conn();

    ~tcp_client();

    //注册消息路由回调函数
    void add_msg_router(int msgid, msg_callback *cb, void *user_data = NULL) 
    {
        _router.register_msg_router(msgid, cb, user_data);
    }

    //----- 链接创建/销毁回调Hook ----
    //设置链接的创建hook函数
    void set_conn_start(conn_callback cb, void *args = NULL) 
    {
        _conn_start_cb = cb;
        _conn_start_cb_args = args;
    }

    //设置链接的销毁hook函数
    void set_conn_close(conn_callback cb, void *args = NULL) {
        _conn_close_cb = cb;
        _conn_close_cb_args = args;
    }

private:
    //当前客户端连接
    int _sockfd;

    //客户端事件的处理机制
    event_loop *_loop;

    //消息分发机制
    msg_router _router;

public:
    //输入缓冲
    INPUT_BUF ibuf;

    //输出缓冲
    OUTPUT_BUF obuf;

    //server端ip地址
    struct sockaddr_in _server_addr;
    socklen_t _addrlen;

    //创建链接之后要触发的 回调函数
    conn_callback _conn_start_cb;     
    void * _conn_start_cb_args;

    //销毁链接之前要触发的 回调函数
    conn_callback _conn_close_cb;
    void * _conn_close_cb_args;

};
