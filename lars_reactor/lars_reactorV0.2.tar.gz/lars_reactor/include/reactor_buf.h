#pragma once

#include <unistd.h>
#include <assert.h>
#include "io_buf.h"
#include "buf_pool.h"


//读写buffer的父类
class REACTOR_BUF
{
public:
    REACTOR_BUF();
    ~REACTOR_BUF();

    //得到当前的buf还有多少数据
    int length();

    //已经处理了多少数据
    void pop(int len);

    //将当前的buf清空
    void clear();

protected:
    IO_BUF *_buf;
};

//fd输入到io_buf,再从io_buf读数据
class INPUT_BUF:public REACTOR_BUF
{
public:
    //从一个fd中读取数据到reactor_buf中
    int read_data(int fd);

    //获取当前的数据
    const char *data();

    //重置缓冲区
    void adjust();
};

//数据写入io_buf，再将io_buf的数据输出到fd
class OUT_PUT:public REACTOR_BUF
{
public:
    //将一段数据写到一个reactor_buf中
    int send_data(const char *data, int datalen);

    //将reactor_buf中的数据写到一个fd中
    int write2fd(int fd);
};
