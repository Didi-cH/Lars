#pragma once

#include <pthread.h>
#include "task_msg.h"
#include "thread_queue.h"

class thread_pool
{
public:
    thread_pool(int thread_cnt);

    //获取一个thead
    thread_queue<task_msg>* get_thread();

private:
    //当前的thread_queue集合
    thread_queue<task_msg> **_queues;
    //线程个数
    int _thread_cnt;
    //线程ID
    pthread_t *_tids;
    //当前选中的线程队列下标
    int _index;
};
