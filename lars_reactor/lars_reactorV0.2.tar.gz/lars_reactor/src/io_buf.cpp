#include <stdio.h>
#include <assert.h>
#include <string.h>
#include <iostream>
#include "io_buf.h"

//构造函数，创建一个size大小的buf
IO_BUF::IO_BUF(int size):capacity(size),length(0),head(0),next(nullptr)
{
    data = new char[size];

    //断言 如果data=nullptr,那么程序直接退出
    assert(data); //assert(data!=nullptr)
}

//清空数据
void IO_BUF::clear()
{
    length = head = 0;
}

//处理长度为len的数据 移动head
void IO_BUF::pop(int len)
{
    head += len;
    length -= len;
}

//将已经处理的数据清空，将未处理的数据移到buf的首地址，length会减小
void IO_BUF::adjust()
{
    if(head!=0)
    {
        if(length!=0)
        {
            // memcpy()函数是从前往后拷贝；假如出现内存重叠的现象；拷贝结果可能出错；
            // memmove()函数在memcpy()函数的基础上加入了对内存重叠拷贝的处理；引入了倒序拷贝的方式处理内存重叠的
            memmove(data, data + head, length);
        }
        head = 0;
    }
}

//将其他的io_buf对象拷贝到自己
void IO_BUF::copy(const IO_BUF *other)
{
    memcpy(data, other->data + other->head, other->length);
    head = 0;
    length = other->length;
}
