#pragma once
/*
 * 
 * 抽象连接类
 *
 * */

class net_connection
{
public:
    //发送消息的接口
    virtual int send_message(const char *data, int datalen, int msgid) = 0;
};

