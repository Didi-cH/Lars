#pragma once
#include "event_loop.h"


//thread_queue消息队列所能够接收的消息类型
struct task_msg
{
    // task_msg一共有两个类型的type
    // 新链接的任务
    // 普通任务 ,主线程希望分发一些任务给每个线程处理
    enum TASK_TYPE
    {
        NEW_CONN,   //新建链接的任务
        NEW_TASK,   //普通任务
    };

    TASK_TYPE type; //任务类型

    //任务本身的数据内容
    union {
        //针对 NEW_CONN新建链接任务，需要传递connfd
        int connfd;

        //针对 NEW_TASK 新建任务, 可以给一个任务提供一个回调函数
        struct {
            void (*task_cb)(event_loop*, void *args);
            void *args;
        };
    };
};