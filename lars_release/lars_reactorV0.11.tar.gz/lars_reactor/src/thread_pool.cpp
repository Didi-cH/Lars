#include "thread_pool.h"
#include "tcp_conn.h"

//IO事件触发的回调函数
// typedef void io_callback(event_loop*, int , void*);
/* 
一旦有task任务消息过来，这个业务函数就会被loop监听到并执行，读出消息队列里的消息并进行处理

 */
void deal_task(event_loop *loop, int fd, void *args)
{
    // 1、从thread_queue中去取数据
    thread_queue<task_msg> *queue = (thread_queue<task_msg> *)args;
    //取出queue调用recv()方法
    std::queue<task_msg> new_task_queue;

    //new_task_queue就是存放的thread_queue的全部任务
    queue->recv(new_task_queue);

    while(!new_task_queue.empty())
    {
        task_msg task = new_task_queue.front();
        new_task_queue.pop();

        // 2、判断task类型
        if(task.type==task_msg::NEW_CONN)
        {
            // 如果是任务1：新建的连接任务
            // queue中取出来的数据就应该是一个刚刚accept成功的connfd new_tcp_conn
            tcp_conn *conn = new tcp_conn(task.connfd, loop);
            if (conn == nullptr) 
            {
                fprintf(stderr, "in thread new tcp_conn error\n");
                exit(1);
            }

            printf("[thread]: get new connection succ!\n");
        }
        else if(task.type==task_msg::NEW_TASK)
        {
            // 如果是任务2：
            // 将该任务添加到event_loop循环中 去执行
            loop->add_task(task.task_cb, task.args);
        }
        else
        {
            //其他未识别任务
            fprintf(stderr, "unknow task!\n");           
        }
    }
 

}

//线程主业务函数
void *thread_main(void *args)
{
    thread_queue<task_msg> *queue = (thread_queue<task_msg>*)args;

    event_loop *loop = new event_loop();

    if (loop == nullptr) {
        fprintf(stderr, "new event_loop error\n");
        exit(1);
    }

    queue->set_loop(loop);
    queue->set_callback(deal_task, queue);

    //启动阻塞监听
    loop->event_process();

    return nullptr;
}

//创建线程池
thread_pool::thread_pool(int thread_cnt)
{
    _queues = nullptr;
    _index = 0;
    _thread_cnt = thread_cnt;

    if (_thread_cnt <= 0) 
    {
        fprintf(stderr, "_thread_cnt < 0\n");
        exit(1);
    }

    //创建thread_queue
    _queues = new thread_queue<task_msg> *[thread_cnt]; //开辟了cnt个thread_queue指针，每个指针并没真正new对象
    _tids = new pthread_t[thread_cnt];

    //开辟线程
    int ret;
    for (int i = 0; i < thread_cnt; ++i) {
        //创建一个线程
        printf("create %d thread\n", i);
        //给一个thread_queue开辟内存，创建对象
         _queues[i] = new thread_queue<task_msg>();
        //第i个线程，绑定第i个thread_queue
        ret = pthread_create(&_tids[i], NULL, thread_main, _queues[i]);
        if (ret == -1) {
            perror("thread_pool, create thread");
            exit(1);
        }

        //将线程脱离
        pthread_detach(_tids[i]);
    }
}

thread_queue<task_msg>* thread_pool::get_thread()
{
    if (_index == _thread_cnt) {
        _index = 0; 
    }

    return _queues[_index++];
}

//发送一个task任务给thread_pool里的全部thread
void thread_pool::send_task(task_func func, void *args)
{
    //封装一个task消息
    task_msg task;
    task.type = task_msg::NEW_TASK;
    task.task_cb = func;
    task.args = args;
    //给当前thread_pool中的每个thread里的pool添加一个task任务
    for (int i = 0; i < _thread_cnt;i++)
    {
        //取出第i个thread的消息队列
        thread_queue<task_msg> *queue = _queues[i];

        //发送task消息
        queue->send(task);        
    }
}
