#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>
#include <sys/types.h>          
#include <sys/socket.h>
#include <arpa/inet.h>
#include <errno.h>
#include <signal.h>

#include "tcp_server.h"
#include "reactor_buf.h"

//==========客户端链接管理部分 ============
//全部已经在线的连接信息
tcp_conn **TCP_SERVER::conns = nullptr;
//最大client链接个数
int TCP_SERVER::_max_conns = 0; 
//当前链接个数    
int TCP_SERVER::_curr_conns = 0;
//保护_curr_conns的锁
pthread_mutex_t TCP_SERVER::_conns_mutex = PTHREAD_MUTEX_INITIALIZER;

//新增一个链接
void TCP_SERVER::increase_conn(int connfd, tcp_conn *conn)
{
    pthread_mutex_lock(&_conns_mutex);
    conns[connfd] = conn;
    _curr_conns++;
    pthread_mutex_unlock(&_conns_mutex);
}

//减少一个链接
void TCP_SERVER::decrease_conn(int connfd)
{
    pthread_mutex_lock(&_conns_mutex);
    conns[connfd] = nullptr;
    _curr_conns--;
    pthread_mutex_unlock(&_conns_mutex);
}

//得到当前的链接个数
void TCP_SERVER::get_conn_num(int *curr_conn)
{
    pthread_mutex_lock(&_conns_mutex);
    *curr_conn = _curr_conns;
    pthread_mutex_unlock(&_conns_mutex);
}

//==========消息分发路由部分 ============
msg_router TCP_SERVER::router;

//=========================回调函数=========================
//listen fd 客户端有新链接请求过来的回调函数
void accept_callback(event_loop *loop, int fd, void *args)
{
    TCP_SERVER *server = (TCP_SERVER*)args;
    server->do_accept();
}

//========================TCP_SERVER成员函数==================================
//构造函数
TCP_SERVER::TCP_SERVER(event_loop *loop, const char *ip, uint16_t port)
{
    //0、忽略一些信号 SIGHUP,SIGPIPE
    //SIGPIPE:如果客户端关闭，服务端再次write就会产生
    //SIGHUP:如果terminal关闭，会给当前进程发送该信号
    if (signal(SIGHUP, SIG_IGN) == SIG_ERR) {
        fprintf(stderr, "signal ignore SIGHUP\n");
    }
    if (signal(SIGPIPE, SIG_IGN) == SIG_ERR) {
        fprintf(stderr, "signal ignore SIGPIPE\n");
    }

    //1、创建socket
    _sockfd = socket(AF_INET, SOCK_STREAM | SOCK_CLOEXEC, IPPROTO_TCP);
    if (_sockfd == -1) {
        fprintf(stderr, "tcp_server::socket()\n");
        exit(1);
    }

    //2、初始化服务器的地址
    struct sockaddr_in server_addr;
    bzero(&server_addr, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    inet_aton(ip, &server_addr.sin_addr);
    server_addr.sin_port = htons(port);

    //设置socket重复监听，设置REUSE
    // 一般来说，一个端口释放后会等待两分钟之后才能再被使用，
    // SO_REUSEADDR是让端口释放后立即就可以被再次使用。
    int op = 1;
    if (setsockopt(_sockfd, SOL_SOCKET, SO_REUSEADDR, &op,sizeof(op))<0)
    {
        fprintf(stderr, "setsocketopt SO_REUSEADDR\n");  
    }

    //3、绑定端口
    if (bind(_sockfd, (const struct sockaddr *)&server_addr, sizeof(server_addr)) < 0)
    {
        fprintf(stderr, "bind error\n");
        exit(1);
    }

    //4、监听ip端口
    if(listen(_sockfd,500)==-1)
    {
        fprintf(stderr, "listen error\n");
        exit(1);
    }

    //5、将_sockfd添加到event_loop中
    _loop = loop;

    //6、创建连接管理
    _max_conns = MAX_CONNS; //TODO从配置文件中去读
    //+3是因为stdin,stdout,stderr 已经被占用，再新开fd一定是从3开始,所以不加3就会栈溢出
    conns = new tcp_conn*[_max_conns+3];
    if (conns == nullptr) {
        fprintf(stderr, "new conns[%d] error\n", _max_conns);
        exit(1);
    }

    //7、注册_socket读事件-->accept处理
    _loop->add_io_event(_sockfd, accept_callback, EPOLLIN, this);
}

//开始提供创建连接的服务
void TCP_SERVER::do_accept()
{
    int connfd;
    while (true)
    {
        //1、accept
        connfd = accept(_sockfd, (struct sockaddr*)&_connaddr, &_addrlen);
        if(connfd == -1)
        {
            if (errno == EINTR) {
                //中断错误
                fprintf(stderr, "accept errno=EINTR\n");
                continue;
            }
            else if (errno == EMFILE) {
                //建立链接过多，资源不够
                fprintf(stderr, "accept errno=EMFILE\n");
            }
            else if (errno == EAGAIN) {
                fprintf(stderr, "accept errno=EAGAIN\n");
                break;
            }
            else {
                fprintf(stderr, "accept error");
                exit(1);
            }  
        }
        else
        {
            //accept succ!
            //判断链接个数是否超过最大值_max_conns
            int cur_conns;
            get_conn_num(&cur_conns);
            //判断链接数量
            if (cur_conns >= _max_conns) 
            {
                fprintf(stderr, "so many connections, max = %d\n", _max_conns);
                close(connfd);
            }
            else 
            {
                //创建一个新的tcp_conn连接对象
                tcp_conn *conn = new tcp_conn(connfd, _loop);
                if (conn == NULL) {
                    fprintf(stderr, "new tcp_conn error\n");
                    exit(1);
                }
                printf("get new connection succ!\n");
            }
            break;
        }
    }
    
}

//析构函数 释放资源
TCP_SERVER::~TCP_SERVER()
{
    close(_sockfd);
}

