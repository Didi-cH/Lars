#include <unistd.h>
#include <string.h>
#include <strings.h>
#include <errno.h>
#include "tcp_client.h"

static void connection_succ(event_loop *loop, int fd, void *args);
void read_callback(event_loop *loop, int fd, void *args);
void write_callback(event_loop *loop, int fd, void *args);


// ======================================================================
//初始化客户端套接字
tcp_client::tcp_client(event_loop *loop, const char *ip, uint16_t port)
{
    _sockfd = -1;
    _msg_callback = nullptr;
    _loop = loop;

    //封装即将要链接的远程server端的ip地址
    bzero(&_server_addr, sizeof(_server_addr));
    _server_addr.sin_family = AF_INET;
    inet_aton(ip, &_server_addr.sin_addr);
    _server_addr.sin_port = htons(port);
    _addrlen = sizeof(_server_addr);

    //链接远程服务器
    this->do_connect();
}

//发送方法
int tcp_client::send_message(const char *data, int msglen, int msgid)
{
    printf("tcp client::send_message()...\n");

    bool active_epollout = false; 
    if(obuf.length() == 0) 
    {
        active_epollout = true;
    }

    //1、封装一个msg包头
    msg_head head;
    head.msgid = msgid;
    head.msglen = msglen;

    //2.1、写消息头
    int ret = obuf.send_data((const char *)&head, MESSAGE_HEAD_LEN);
    if (ret != 0) {
        fprintf(stderr, "send head error\n");
        return -1;
    }
    //2.2 写消息体
    ret = obuf.send_data(data, msglen);
    if (ret != 0) {
        //如果写消息体失败，消息头的发送也取消
        obuf.pop(MESSAGE_HEAD_LEN);
        return -1;
    }

    if (active_epollout == true) {
        //3、将_connfd添加一个写事件EPOLLOUT
        _loop->add_io_event(_sockfd, write_callback, EPOLLOUT, this);
    }
    return 0;
}

//处理读业务
void tcp_client::do_read()
{
    printf("tcp client::do_read()...\n");
    //1、从_sockfd读取数据
    int ret = ibuf.read_data(_sockfd);
    if (ret == -1) {
        fprintf(stderr, "read data from socket\n");
        this->clean_conn();
        return ;
    }
    else if ( ret == 0) {
        //对端正常关闭
        printf("connection closed by peer\n");
        clean_conn();
        return ;
    }

    msg_head head;
    //2、尽可能一次性读取多个完整包过来 ，满足8字节
    while(ibuf.length()>=MESSAGE_HEAD_LEN)
    {
        //2.1 先读头部，得到msgid,msglen
        memcpy(&head, ibuf.data(), MESSAGE_HEAD_LEN);
        if(head.msglen > MESSAGE_LENGTH_LIMIT || head.msglen < 0) {
            fprintf(stderr, "data format error, need close, msglen = %d\n", head.msglen);
            this->clean_conn();
            break;
        }
        //2.2 判断msglen,和length是否一致
        if (ibuf.length() < MESSAGE_HEAD_LEN + head.msglen) {
            //缓存buf中剩余的数据，小于实际上应该接受的数据
            //说明是一个不完整的包，应该抛弃
            break;
        }

        //头部处理完了，往后偏移MESSAGE_HEAD_LEN长度
        ibuf.pop(MESSAGE_HEAD_LEN);
              
        //将得到的数据做一个固定的链接业务（回显）
        if(_msg_callback!=nullptr)
        {
            this->_msg_callback(ibuf.data(), head.msglen, head.msgid, this, NULL);
        }

        //消息体处理完了,往后偏移msglen长度
        ibuf.pop(head.msglen);
    }

    ibuf.adjust();

    return;
}

//处理写业务
void tcp_client::do_write()
{
    printf("tcp client::do_write()...\n");

    while (obuf.length()) 
    {
        int ret = obuf.write2fd(_sockfd);
        if (ret == -1) {
            fprintf(stderr, "tcp_client write error, close conn!\n");
            this->clean_conn();
            return ;
        }
        if (ret == 0) {
            //不是错误，仅返回0表示不可继续写
            break;
        }
    }

    if (obuf.length() == 0) {
        //数据已经全部写完，将_sockfd的写事件取消掉
        _loop->del_io_event(_sockfd, EPOLLOUT);
    }

    return;
}

//链接服务器
void tcp_client::do_connect()
{
    if (_sockfd != -1) 
    {
        close(_sockfd);
    }

    //创建套接字
    _sockfd = socket(AF_INET, SOCK_STREAM | SOCK_CLOEXEC | SOCK_NONBLOCK, IPPROTO_TCP);
    if (_sockfd == -1) {
        fprintf(stderr, "create tcp client socket error\n");
        exit(1);
    }

    int ret = connect(_sockfd, (const struct sockaddr*)&_server_addr, _addrlen);
    if(ret==0)
    {
        //链接创建成功

        //主动由开发者手动调用send_message方法来发包
        printf("connect ret=0, connect %s:%d succ!\n", inet_ntoa(_server_addr.sin_addr), ntohs(_server_addr.sin_port));

        // static void connection_succ(event_loop *loop, int fd, void *args);
        connection_succ(_loop, _sockfd, this);
    }
    else
    {
        if(errno == EINPROGRESS) {
            //fd是非阻塞的，可能会出现这个错误,但是并不表示链接创建失败
            //如果fd是可写状态，则为链接是创建成功的.
            fprintf(stderr, "do_connect EINPROGRESS\n");

            //让event_loop去检测当前的sockfd是否可写，如果当前回调被执行，说明可写，则连接创建成功
            _loop->add_io_event(_sockfd, connection_succ, EPOLLOUT, this);
        }
        else {
            fprintf(stderr, "connection error\n");
            exit(1);
        }
    }  
}

//释放连接
void tcp_client::clean_conn()
{
    if (_sockfd != -1) {
        printf("clean conn, del socket!\n");
        _loop->del_io_event(_sockfd);
        close(_sockfd);
    }

    //重新连接
    this->do_connect();
}

tcp_client::~tcp_client()
{
    close(_sockfd);
}

//======================================================================
//判断链接是否是创建成功，主要是针对非阻塞socket 返回EINPROGRESS错误
static void connection_succ(event_loop *loop, int fd, void *args)
{
    printf("connect succ!!\n");
    tcp_client *client = (tcp_client*)args;
    loop->del_io_event(fd);

    //再对当前fd进行一次错误编码的获取，如果没有任何错误，那么就一定成功了
    //如果有，认为fd是没有创建成功，链接创建失败
    int result = 0;
    socklen_t result_len = sizeof(result);
    getsockopt(fd, SOL_SOCKET, SO_ERROR, &result, &result_len);
    if (result == 0) 
    {
        //链接是建立成功的

        printf("connect %s:%d succ!\n", inet_ntoa(client->_server_addr.sin_addr), ntohs(client->_server_addr.sin_port));

        //连接创建成功之后的一些业务

        //客户端业务
        //建立连接成功之后，主动发送send_message
        const char *msg = "hello lars! I am client.";
        int msgid = 1;

        //将数据写client的obuf中
        client->send_message(msg, strlen(msg), msgid);

        if (client->obuf.length() != 0) {
            //让event_loop触发写回调业务
            loop->add_io_event(fd, write_callback, EPOLLOUT, client);
        }

        //添加针对当前client的fd的读回调
        loop->add_io_event(fd, read_callback, EPOLLIN, client);
    }
    else {
        //链接创建失败
        fprintf(stderr, "connection %s:%d error\n", inet_ntoa(client->_server_addr.sin_addr), ntohs(client->_server_addr.sin_port));
        return;
    }


}

void read_callback(event_loop *loop, int fd, void *args)
{
    tcp_client *client= (tcp_client *)args;
    client->do_read();
}

void write_callback(event_loop *loop, int fd, void *args)
{
    tcp_client *client= (tcp_client *)args;
    client->do_write();
}