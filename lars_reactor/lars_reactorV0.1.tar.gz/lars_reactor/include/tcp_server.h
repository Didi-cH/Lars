#pragma once

#include <netinet/in.h>

class TCP_SERVER
{
public:
    //构造函数
    TCP_SERVER(const char *ip, uint16_t port);

    //开始提供创建连接的服务
    void do_accept();

    //析构函数 释放资源
    ~TCP_SERVER();

private:
    int _sockfd; //套接字 监听文件描述符
    struct sockaddr_in _connaddr; //客户端链接地址
    socklen_t _addrlen; //客户端连接地址长度
};
